from django.utils.translation import ugettext_lazy as _
from mysite.settings.components.config_file import CONFIG_FILE
from mysite.settings.components import BASE_DIR

DEFAULT_ADMIN_NAME = 'admin'
DEFAULT_ADMIN_PASS = 'admin'
ANONYMOUS_USER_NAME = None

PROJECT_NAME = 'BioTime 8.5'

USE_TZ = False
USE_L10N = False
DATETIME_FORMAT = 'Y-m-d H:i:s'
STD_DATETIME_FORMAT = '%Y-%m-%d %H:%M:%S'
STD_DATE_FORMAT = '%Y-%m-%d'
STD_TIME_FORMAT = '%H:%M:%S'
ENCRYPT_DB_PWD = 0

ENABLED_MOD = ['personnel', 'att', 'device', 'payroll', 'acc', 'visitor', 'meeting', 'system', 'staff_payroll',
               'staff_meeting', 'staff_visitor', 'ep']

STANDARD_MODULES = [
    {'id': 'personnel', 'caption': _('menu_personnel')},
    {'id': 'adms', 'caption': _('menu_adms')},
    {'id': 'iclock', 'caption': _('menu_terminal')},
    {'id': 'att', 'caption': _('menu_attendance')},
    {'id': 'acc', 'caption': _('menu_access')},
    {'id': 'payroll', 'caption': _('menu_payroll')},
    {'id': 'visitor', 'caption': _('menu.visitor')},
    {'id': 'meeting', 'caption': _('app.menus.meeting')},
    {'id': 'ep', 'caption': _('menus.epidemicPrevention')},
    {'id': 'base', 'caption': _('menu_system')},
    {'id': 'staff', 'caption': _('menu_attendance')},
    {'id': 'staff_payroll', 'caption': _('menu_payroll')},
    {'id': 'staff_visitor', 'caption': _('menu.visitor')},
    {'id': 'staff_meeting', 'caption': _('app.menus.meeting')},
]
WDMS_MODULES = [
    {'id': 'personnel', 'caption': _('menu_personnel')},
    {'id': 'adms', 'caption': _('menu_adms')},
    {'id': 'iclock', 'caption': _('menu_terminal')},
    {'id': 'ep', 'caption': _('menus.epidemicPrevention')},
    {'id': 'base', 'caption': _('menu_system')},
]

SALE_MODULE = []

MOD_DICT = {
    'personnel': 0, 'adms': 9, 'att': 9, 'meeting': 1, 'patrol': 2,
    'acc': 5, 'access': 4, 'ipos': 3
}

# module control
ENABLE_PSNL = True
ENABLE_DEV = True
ENABLE_ATT = True
ENABLE_PAYROLL = True
ENABLE_ACC = True
ENABLE_MEETING = False
ENABLE_SYSTEM = True
ENABLE_STAFF = True
ENABLE_WDMS = False
ENABLE_EP = True

# function control
ENABLE_FREE_API = True
ENABLE_MIDDLE_TABLE = True

# image ENCRYPT AES
ENABLE_ENCRYPT_PHOTO = True
IMAGE_AES_PASSWORD = CONFIG_FILE.get('SYS', 'IMAGE_AES_PASSWORD', fallback='8GLAr7kpw4SSx89xVHV9Tly7vU7sqgqL').encode(
    'utf8')
IMAGE_AES_IV = IMAGE_AES_PASSWORD[8:24]
IMAGE_AES_PREFIX = b'eav101$'

SITE_TITLE = ""
ALL_TAG = "ALL"

# setting show all api docs
SHOW_ALL_API_DOCS = False
# setting enable IsOpenAPIPermission
ENABLE_IsOpenAPIPermission = True

LOGIN_REDIRECT_URL = "/"
LOGIN_URL = "/login/"

DEPT_VERSION = 1

POSITION_VERSION = 1

AREA_VERSION = 1

PREPARE_CMD_SIZE = 200

MAX_USER_PHOTO_SIZE = 25 * 1024

UNIT = ""

COMPANY = ''

MAX_DEVICES_STATE = 200

ACTIVE_APP_LOCATION = 1

ISVALIDDONGLE = True

DEV_STATUS_SAVE = 0

ICLOCK_AUTO_REG = 1

# department tree control
DEPT_COUNT = 0

# DISABLED_PINS = ['0', 0]
DISABLED_PINS = []

DETPARTMENT_VERSION = 1

MAX_CACHE_VALUE = 1024 * 1024

CACHE_PHOTO = False

DEFAULT_DEVICE_ALIAS = "Auto add"

MAX_DAYS = 0

CLOSE_DATE = ''

# RSA encryption public key
PUBLIC_KEY = '''-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQD1DrTOZrqQyjS9qHlrNc+PmIRR
pNJ5NAvszZJPUrVpedU31un+UMHy98HZf9THqnETWazQcUIcwAtl6POtY3g56Bz2
WMzUJ5+n7E3Wi4EZsptdVsIx7xFcWsA5Cg8Aj4dI6maN19WbjSxaIWHWie2GCxfg
Ct6E55p2o0++pX9GQwIDAQAB
-----END PUBLIC KEY-----'''

# XSS risk check function in form
ENABLE_XSS_CHECK = CONFIG_FILE.getint('SYS', 'ENABLE_XSS_CHECK', fallback=0)

# uncategorized  field
ACC_TRAN_SHOWBLUE = True
APPEND_SLASH = False
APP_VERSION = '10.0'
AUTHORIZED_APP = 2
AUTHORIZED_EMPLOYEE = 1000
AUTO_PROXY_IP = ''
AUTO_TRAN = False
AUTO_TRAN_ING = False
CACHE_CMD = False
CARDTYPE = -1
CFG = None
COMPANY_NAME = 'BioTime-8.5'
CUSTOM_ID = 0
CUSTOM_NO = ''
DATA_UPLOAD_MAX_MEMORY_SIZE = 50 * 1024 * 1024
DATA_UPLOAD_MAX_NUMBER_FIELDS = 10240
DISTANCE = 200
DONGLEHID = ''
DUBAI_USED = True
EMPLOYEE_AUTO_NUMBER = CONFIG_FILE.getint('SYS', 'EMPLOYEE_AUTO_NUMBER', fallback=1)
EMPLOYEE_COUNT = 0
ENCRYPT = 0
ERRORCODE = 0
FILE_UPLOAD_MAX_MEMORY_SIZE = 50 * 1024 * 1024
HASDONGLE = False
IDFORPIN = CONFIG_FILE.getint('SYS', 'IDFORPIN', fallback=0)
IPAddressByDevice = CONFIG_FILE.get('SYS', 'IPAddressByDevice', fallback='1')
LICENSE_NAME = ''
MAC = ''
MAXFP_L = 598
MAX_DEVICES = 0
MAX_EXPORT_COUNT = 20000
MAX_UPDATE_COUNT = 50
MCOUNT = 0
MIN_REQ_DELAY = 60
MIN_TRANSINTERVAL = 2
NATIVE_ENCODE = 'GB18030'
NOCMD_DEVICES = []
PAGE_LIMIT = 30
PKEY = ''
PRODUCTCODE = 15
'''
PRODUCT_CODE
15:BioTime 17:WDMS
'''
PRODUCT_CODE = 15  # change to 17 manually if using WDMS

if PRODUCT_CODE == 17:
    PROJECT_NAME = _('WDMS_web_title')
    ENABLE_WDMS = True
else:
    PROJECT_NAME = _('BioTime 8.5')
    ENABLE_WDMS = False

REBOOT_CHECKTIME = 0
ROSETTA_REQUIRES_AUTH = False
SITETITLE = ''
TRANS_REALTIME = 1
TRIALVERSION = 0
UPDATE_COUNT = 0
UPGRADE_FWVERSION = ''
ENABLE_SECURITY_POLICY = True
PROGRESS_INTERVAL = 100
DATABASE_BACKUP_PATH = CONFIG_FILE.get('SYS', 'DATABASE_BACKUP_PATH', fallback=BASE_DIR + '/files/backup/')

ASYN_CMD_RESULT = CONFIG_FILE.getint('SYS', 'ASYN_CMD_RESULT', fallback=0)
ASYN_DEV_PARAMETER = CONFIG_FILE.getint('SYS', 'ASYN_DEV_PARAMETER', fallback=0)

ASYN_PROGRESS_TASK_SYNC = CONFIG_FILE.getint('SYS', 'ASYN_PROGRESS_TASK_SYNC', fallback=1)
ENABLE_VISITOR = CONFIG_FILE.getint('VISITOR', 'VISIBLE', fallback=1)
ENABLE_PAYROLL = CONFIG_FILE.getint('PAYROLL', 'VISIBLE', fallback=1)
ENABLE_MEETING = CONFIG_FILE.getint('MEETING', 'VISIBLE', fallback=1)
AUSTRALIA = CONFIG_FILE.getint('LOCAL', 'AUSTRALIA', fallback=0)
ENABLE_EP = CONFIG_FILE.getint('LOCAL', 'MTD', fallback=1)
ENABLE_DATA_COMPARY = CONFIG_FILE.getint('SYS', 'ENABLE_DATA_COMPARY', fallback=0)

ACCOUNT_COOKIE_NAME = 'account_info'
ACCOUNT_COOKIE_AGE = 5 * 24 * 60 * 60

ALLOW_MULTIPLE_COMPANY = CONFIG_FILE.getint('SYS', 'ALLOW_MULTIPLE_COMPANY', fallback=0)

HEX_CARD = CONFIG_FILE.getint('SYS', 'HEX_CARD', fallback=0)

CMD_CELERY = CONFIG_FILE.getint('SYS', 'CMD_CELERY', fallback=0)
ASYN_EXPORT_REPORT = CONFIG_FILE.getint('SYS', 'ASYN_EXPORT_REPORT', fallback=0)
ASYN_IMPORT_DATA = CONFIG_FILE.getint('SYS', 'ASYN_IMPORT_DATA', fallback=0)
ASYN_SAVE_DEVICE_PHOTO = CONFIG_FILE.getint('SYS', 'ASYN_SAVE_DEVICE_PHOTO', fallback=0)
ASYN_SAVE_DEVICE_UPLOAD_LOG = CONFIG_FILE.getint('SYS', 'ASYN_SAVE_DEVICE_UPLOAD_LOG', fallback=0)
FAST_CALCULATE = CONFIG_FILE.getint('SYS', 'FAST_CALCULATE', fallback=1)
EMPLOYEE_CACHE = CONFIG_FILE.getint('SYS', 'EMPLOYEE_CACHE', fallback=1)
AUSTRALIA = CONFIG_FILE.getint('LOCAL', 'AUSTRALIA', fallback=0)
MEETING_USING = CONFIG_FILE.getint('MEETING', 'USING', fallback=0)
TRANSACTION_PACKAGE_SIZE = CONFIG_FILE.getint('SYS', 'TRANSACTION_PACKAGE_SIZE', fallback=0)