# When customizing or solution development is ready for release and delivery
# please modify specific VERSION
# for Windows platform, it is used by 'python cab.py'  ** not use fornow --damien **
VERSION = '8.5.5 dev (Build:20250805.2925_Asc_Qahtani)'
